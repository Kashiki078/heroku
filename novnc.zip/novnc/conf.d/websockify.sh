#!/bin/bash
websockify --web /usr/share/novnc $PORT localhost:5900